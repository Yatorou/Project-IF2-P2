To learn more about the font family and its license, visit https://www.fontmirror.com/doknatle

License: Free for personal use.
This is a preview font for testing, you can purchase its full version at https://www.creativefabrica.com/product/doknatle/ref/1095569/.
Contact storytypestudio@gmail.com for commercial use.
You can donate to the font author at https://www.paypal.com/paypalme/letterenastudios.
 